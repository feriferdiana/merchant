package com.merchant.model.merchanttype;

import lombok.Data;

@Data
public class MerchantTypeRequest {
    private String id;
    private String name;
}
