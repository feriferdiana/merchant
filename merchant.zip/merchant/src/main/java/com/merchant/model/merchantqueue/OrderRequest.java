package com.merchant.model.merchantqueue;

import lombok.Data;

import java.util.List;

@Data
public class OrderRequest {
    private String bardcode;
    private String customerName;
    private List<String> menu;
}
