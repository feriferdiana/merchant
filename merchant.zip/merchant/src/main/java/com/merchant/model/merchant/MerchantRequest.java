package com.merchant.model.merchant;

import lombok.Data;

@Data
public class MerchantRequest {
    private String idMerchantType;
    private String code;
    private String name;
    private String address;
    private String owner;
    private String bardcode;
}
