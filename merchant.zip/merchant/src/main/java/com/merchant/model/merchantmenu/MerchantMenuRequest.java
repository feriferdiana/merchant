package com.merchant.model.merchantmenu;

import lombok.Data;

import java.util.List;

@Data
public class MerchantMenuRequest {
    private String idMerchant;
    private List<String> menu;
}
