package com.merchant.model;

import lombok.Data;

@Data
public class DataResponse {
    private String status;
    private String code;
    private Object data;
}
