package com.merchant.model.merchantqueue;

import com.merchant.entity.Merchant;
import com.merchant.entity.MerchantMenu;
import com.merchant.entity.MerchantQueue;
import com.merchant.entity.MerchantQueueMenu;
import com.merchant.service.MerchantQueueService;
import lombok.Data;

import java.util.List;

@Data
public class OrderCheckResponse {
    private MerchantQueue merchantQueue;
    private List<MerchantQueueMenu> merchantQueueMenu;
}
