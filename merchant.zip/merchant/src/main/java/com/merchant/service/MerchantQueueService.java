package com.merchant.service;

import com.merchant.entity.Merchant;
import com.merchant.entity.MerchantMenu;
import com.merchant.entity.MerchantQueue;
import com.merchant.entity.MerchantQueueMenu;
import com.merchant.enumeration.StatusBooking;
import com.merchant.library.GenerateUUID;
import com.merchant.model.DataResponse;
import com.merchant.model.merchantqueue.OrderCheckResponse;
import com.merchant.model.merchantqueue.OrderRequest;
import com.merchant.model.merchantqueue.OrderResponse;
import com.merchant.repository.MerchantMenuRepository;
import com.merchant.repository.MerchantQueueMenuRepository;
import com.merchant.repository.MerchantQueueRepository;
import com.merchant.repository.MerchantRepository;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
@AllArgsConstructor
public class MerchantQueueService {

    private MerchantRepository merchantRepository;
    private MerchantMenuRepository merchantMenuRepository;
    private MerchantQueueRepository merchantQueueRepository;
    private MerchantQueueMenuRepository merchantQueueMenuRepository;

    public DataResponse order(OrderRequest request){

        DataResponse dataResponse = new DataResponse();

        Merchant merchant = merchantRepository.byBarcode(request.getBardcode());
        if (merchant == null) {
            dataResponse.setStatus("error");
            dataResponse.setCode("400");
            dataResponse.setData("Merchant tidak ditemukan");
            return dataResponse;
        }

        if (request.getMenu().size() == 0) {
            dataResponse.setStatus("error");
            dataResponse.setCode("400");
            dataResponse.setData("Silahkan pilih menu terlebih dahulu");
            return dataResponse;
        }

        List<MerchantQueue> merchantQueue = merchantQueueRepository.byMerchantId(merchant.getId());
        String codeBooking = merchant.getCode();
        BigInteger numberOrderBooking;
        if(merchantQueue.size() == 0){
            codeBooking = codeBooking.concat("-").concat(String.valueOf(1));
            numberOrderBooking = new BigInteger("1");
        }
        else{
            String[] orderBooking = merchantQueue.get(0).getCodeBooking().split("-");
            numberOrderBooking = new BigInteger(orderBooking[1]).add(new BigInteger("1"));

            codeBooking = codeBooking.concat("-").concat(String.valueOf(numberOrderBooking));
        }

        // save order
        MerchantQueue merchantQueueRequest = new MerchantQueue();
        String idMerchantQueue = GenerateUUID.id();
        log.info("id order {}", idMerchantQueue);
        merchantQueueRequest.setId(idMerchantQueue);
        merchantQueueRequest.setIdMerchant(merchant.getId());
        merchantQueueRequest.setCodeBooking(codeBooking);
        merchantQueueRequest.setCustomerName(request.getCustomerName());
        merchantQueueRequest.setOrderDatetime(LocalDateTime.now());
        merchantQueueRequest.setOrderQueue(numberOrderBooking);
        merchantQueueRequest.setStatus(StatusBooking.ON_PROGRESS.name());
        merchantQueueRepository.save(merchantQueueRequest);

        // save order menu
        List<MerchantQueueMenu> merchantQueueMenuList = new ArrayList<>();
        for(String menu : request.getMenu()){
            MerchantMenu merchantMenu = merchantMenuRepository.byId(menu);
            if(merchantMenu != null){
                MerchantQueueMenu merchantQueueMenuRequest = new MerchantQueueMenu();
                merchantQueueMenuRequest.setId(GenerateUUID.id());
                merchantQueueMenuRequest.setIdMerchantQueue(idMerchantQueue);
                merchantQueueMenuRequest.setIdMerchantMenu(merchantMenu.getId());
                merchantQueueMenuRepository.save(merchantQueueMenuRequest);

                merchantQueueMenuList.add(merchantQueueMenuRequest);
            }
        }

        OrderResponse orderResponse = new OrderResponse();
        orderResponse.setMerchantQueue(merchantQueueRequest);
        orderResponse.setMerchantQueueMenu(merchantQueueMenuList);

        dataResponse.setStatus("OK");
        dataResponse.setCode("200");
        dataResponse.setData(orderResponse);

        return dataResponse;

    }

    public DataResponse completed(String id){

        DataResponse dataResponse = new DataResponse();

        MerchantQueue merchantQueue = merchantQueueRepository.byId(id);
        if(merchantQueue == null){
            dataResponse.setStatus("error");
            dataResponse.setCode("400");
            dataResponse.setData("Order tidak ditemukan");
            return dataResponse;
        }

        merchantQueueRepository.update(id);

        dataResponse.setStatus("OK");
        dataResponse.setCode("200");

        return dataResponse;

    }

    public DataResponse check(String id){

        DataResponse dataResponse = new DataResponse();

        MerchantQueue merchantQueue = merchantQueueRepository.byId(id);
        List<MerchantQueueMenu> merchantQueueMenu = merchantQueueMenuRepository.byidMerchant(id);

        OrderCheckResponse orderCheckResponse = new OrderCheckResponse();
        orderCheckResponse.setMerchantQueue(merchantQueue);
        orderCheckResponse.setMerchantQueueMenu(merchantQueueMenu);

        dataResponse.setStatus("OK");
        dataResponse.setCode("200");
        dataResponse.setData(orderCheckResponse);

        return dataResponse;
    }
}
