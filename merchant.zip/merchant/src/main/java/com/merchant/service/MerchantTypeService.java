package com.merchant.service;

import com.merchant.entity.MerchantType;
import com.merchant.library.GenerateUUID;
import com.merchant.model.DataResponse;
import com.merchant.model.merchanttype.MerchantTypeRequest;
import com.merchant.repository.MerchantTypeRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Service
@AllArgsConstructor
public class MerchantTypeService {

    private MerchantTypeRepository merchantTypeRepository;

    public DataResponse all(){
        try{
            List<MerchantType> merchantType = merchantTypeRepository.findAll();

            DataResponse dataResponse = new DataResponse();
            dataResponse.setCode("200");
            dataResponse.setStatus("OK");
            dataResponse.setData(merchantType);

            return dataResponse;

        } catch (Exception e){

            DataResponse dataResponse = new DataResponse();
            dataResponse.setCode("500");
            dataResponse.setStatus("System Failure");

            return dataResponse;
        }
    }

    public DataResponse byId(String id){
        try{
            MerchantType merchantType = merchantTypeRepository.byId(id);

            DataResponse dataResponse = new DataResponse();
            dataResponse.setCode("200");
            dataResponse.setStatus("OK");
            dataResponse.setData(merchantType);

            return dataResponse;
        }catch (NullPointerException e){

            DataResponse dataResponse = new DataResponse();
            dataResponse.setCode("201");
            dataResponse.setStatus("OK");

            return dataResponse;

        } catch (Exception e){

            DataResponse dataResponse = new DataResponse();
            dataResponse.setCode("500");
            dataResponse.setStatus("System Failure");

            return dataResponse;
        }
    }

    public DataResponse insert(MerchantTypeRequest request){
        try{
            MerchantType merchantType = new MerchantType();
            merchantType.setId(GenerateUUID.id());
            merchantType.setType(request.getName());
            merchantType.setCreatedDate(LocalDateTime.now());

            merchantTypeRepository.save(merchantType);

            DataResponse dataResponse = new DataResponse();
            dataResponse.setCode("200");
            dataResponse.setStatus("OK");
            dataResponse.setData(merchantType);

            return dataResponse;
        }catch (Exception e){

            DataResponse dataResponse = new DataResponse();
            dataResponse.setCode("500");
            dataResponse.setStatus("System Failure");

            return dataResponse;
        }
    }

    public DataResponse update(MerchantTypeRequest request){

        MerchantType merchantType = merchantTypeRepository.byId(request.getId());
        if(merchantType == null){
            DataResponse dataResponse = new DataResponse();
            dataResponse.setCode("400");
            dataResponse.setStatus("Data not found");

            return dataResponse;
        }
        else{
            merchantTypeRepository.update(request.getId(), request.getName());

            MerchantType updateMerchantType = merchantTypeRepository.byId(request.getId());
            merchantType.setType(request.getName());
            DataResponse dataResponse = new DataResponse();
            dataResponse.setCode("200");
            dataResponse.setStatus("OK");
            dataResponse.setData(updateMerchantType);

            return dataResponse;
        }
    }

    public DataResponse delete(String id){

        MerchantType merchantType = merchantTypeRepository.byId(id);
        if(merchantType == null){
            DataResponse dataResponse = new DataResponse();
            dataResponse.setCode("400");
            dataResponse.setStatus("Data not found");

            return dataResponse;
        }
        else{
            merchantTypeRepository.delete(merchantType);

            DataResponse dataResponse = new DataResponse();
            dataResponse.setCode("200");
            dataResponse.setStatus("OK");

            return dataResponse;
        }
    }
}
