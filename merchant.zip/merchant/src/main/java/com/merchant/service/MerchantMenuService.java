package com.merchant.service;

import com.merchant.entity.Merchant;
import com.merchant.entity.MerchantMenu;
import com.merchant.library.GenerateUUID;
import com.merchant.model.DataResponse;
import com.merchant.model.merchantmenu.MerchantMenuRequest;
import com.merchant.repository.MerchantMenuRepository;
import com.merchant.repository.MerchantRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@AllArgsConstructor
public class MerchantMenuService {

    private MerchantRepository merchantRepository;
    private MerchantMenuRepository merchantMenuRepository;

    public DataResponse addMenu(MerchantMenuRequest request){

        DataResponse dataResponse = new DataResponse();

        Merchant merchant = merchantRepository.byId(request.getIdMerchant());
        if(merchant == null){
            dataResponse.setStatus("error");
            dataResponse.setCode("400");
            dataResponse.setData("Merchant tidak ditemukan");
            return dataResponse;
        }

        for(String menu : request.getMenu()){
            MerchantMenu merchantMenu = new MerchantMenu();
            merchantMenu.setId(GenerateUUID.id());
            merchantMenu.setIdMerchant(request.getIdMerchant());
            merchantMenu.setMenu(menu);

            merchantMenuRepository.save(merchantMenu);
        }

        dataResponse.setStatus("OK");
        dataResponse.setCode("200");

        return dataResponse;

    }
}
