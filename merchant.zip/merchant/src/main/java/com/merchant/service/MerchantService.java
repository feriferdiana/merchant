package com.merchant.service;

import com.merchant.entity.Merchant;
import com.merchant.entity.MerchantType;
import com.merchant.entity.Owner;
import com.merchant.library.GenerateUUID;
import com.merchant.model.DataResponse;
import com.merchant.model.merchant.MerchantRequest;
import com.merchant.repository.MerchantRepository;
import com.merchant.repository.MerchantTypeRepository;
import com.merchant.repository.OwnerRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@AllArgsConstructor
public class MerchantService {

    private MerchantRepository merchantRepository;
    private MerchantTypeRepository merchantTypeRepository;
    private OwnerRepository ownerRepository;

    public DataResponse register(MerchantRequest request){

        DataResponse dataResponse = new DataResponse();

        Owner owner = ownerRepository.findById(request.getOwner());
        MerchantType merchantType = merchantTypeRepository.byId(request.getIdMerchantType());
        Merchant merchantCode = merchantRepository.byCode(request.getCode());

        if(owner == null && merchantType == null){
            dataResponse.setStatus("error");
            dataResponse.setCode("400");
            dataResponse.setData("Owner dan Kategori merchant tidak ditemukan");
            return dataResponse;
        }

        if(owner == null){
            dataResponse.setStatus("error");
            dataResponse.setCode("400");
            dataResponse.setData("Owner tidak ditemukan");
            return dataResponse;
        }

        if(merchantType == null){
            dataResponse.setStatus("error");
            dataResponse.setCode("400");
            dataResponse.setData("Kategori merchant tidak ditemukan");
            return dataResponse;
        }

        if(merchantCode != null){
            dataResponse.setStatus("error");
            dataResponse.setCode("400");
            dataResponse.setData("Kode merchant sudah digunakan, silahkan gunakan kode lain");
            return dataResponse;
        }

        Merchant merchant = new Merchant();
        merchant.setId(GenerateUUID.id());
        merchant.setIdMerchantType(merchantType.getId());
        merchant.setCode(request.getCode());
        merchant.setOwner(owner.getId());
        merchant.setName(request.getName());
        merchant.setAddress(request.getAddress());
        merchant.setBarcode(request.getBardcode());

        merchantRepository.save(merchant);

        dataResponse.setStatus("OK");
        dataResponse.setCode("200");
        dataResponse.setData(merchant);

        return dataResponse;

    }
}
