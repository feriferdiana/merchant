package com.merchant.service;

import com.merchant.entity.Owner;
import com.merchant.entity.UserRegistrationHistory;
import com.merchant.entity.Users;
import com.merchant.library.GenerateUUID;
import com.merchant.model.DataResponse;
import com.merchant.model.users.LoginRequest;
import com.merchant.model.users.RegisterRequest;
import com.merchant.repository.OwnerRepository;
import com.merchant.repository.UserRegistrationHistoryRepository;
import com.merchant.repository.UsersRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
@AllArgsConstructor
public class UsersService {

    private UsersRepository usersRepository;
    private UserRegistrationHistoryRepository userRegistrationHistoryRepository;
    private OwnerRepository ownerRepository;

    public List<Users> getAllUsers(){
        return usersRepository.getAll();
    }

    public ResponseEntity<DataResponse> login(LoginRequest request){

        DataResponse dataResponse = new DataResponse();

        if(request.getPassword() == null || request.getUsername() == null){
            dataResponse.setStatus("error");
            dataResponse.setCode("400");
            dataResponse.setData("Username dan / atau password kosong");
            return ResponseEntity.badRequest().body(dataResponse);
        }
        else{

            String[] splitUsername = request.getUsername().split("");
            String[] splitPassword = request.getPassword().split("");

            String text = "";
            int index = 0;
            for(String sp : splitPassword){
                sp += splitUsername[index];
                log.info("sp {}", sp);

                text += sp;
                index++;
            }

            StringBuilder builder = new StringBuilder();
            log.info("text {}", text);
            builder.append(text);
            builder.reverse();
            log.info("reverse {}", builder);

            Users users = usersRepository.findUsers(request.getUsername(), request.getPassword());
            if (users == null){
                dataResponse.setStatus("error");
                dataResponse.setCode("401");
                dataResponse.setData("Username dan / atau password kosong");
                return ResponseEntity.status(401).body(dataResponse);
            }
            else{
                dataResponse.setStatus("ok");
                dataResponse.setCode("200");
                dataResponse.setData("Success Login");
                return ResponseEntity.ok(dataResponse);
            }
        }
    }

    public ResponseEntity<DataResponse> regis(RegisterRequest request){

        DataResponse dataResponse = new DataResponse();

        Users findUsername = usersRepository.findUsername(request.getUsername());
        if(findUsername != null){
            dataResponse.setStatus("error");
            dataResponse.setCode("409");
            dataResponse.setData("Username sudah terpakai");
            return ResponseEntity.status(409).body(dataResponse);
        }
        else{

            String idUser = GenerateUUID.id();

            Users dataUser = new Users();
            dataUser.setId(idUser);
            dataUser.setUsername(request.getUsername());
            dataUser.setPassword(request.getPassword());
            usersRepository.save(dataUser);

            UserRegistrationHistory userRegistrationHistory = new UserRegistrationHistory();
            userRegistrationHistory.setId(GenerateUUID.id());
            userRegistrationHistory.setUsername(request.getUsername());
            userRegistrationHistory.setPassword(request.getPassword());
            userRegistrationHistoryRepository.save(userRegistrationHistory);

            Owner owner = new Owner();
            owner.setId(GenerateUUID.id());
            owner.setIdUser(idUser);
            owner.setName(request.getFullName());
            ownerRepository.save(owner);

            dataResponse.setStatus("success");
            dataResponse.setCode("201");
            dataResponse.setData("ok");
            return ResponseEntity.status(201).body(dataResponse);
        }
    }

    public ResponseEntity<DataResponse> update(LoginRequest request){

        DataResponse dataResponse = new DataResponse();

        Users findUsername = usersRepository.findUsername(request.getUsername());
        if(findUsername == null){
            dataResponse.setStatus("error");
            dataResponse.setCode("400");
            dataResponse.setData("Username tidak ditemukan");
            return ResponseEntity.status(400).body(dataResponse);
        }

        List<UserRegistrationHistory> userRegistrationHistoryList = userRegistrationHistoryRepository.getByUsername(request.getUsername());
        if(userRegistrationHistoryList.size() > 0){
            for(UserRegistrationHistory data : userRegistrationHistoryList){
                if(data.getUsername().equals(request.getUsername())
                && data.getPassword().equals(request.getPassword())){
                    dataResponse.setStatus("error");
                    dataResponse.setCode("409");
                    dataResponse.setData("Password tidak boleh sama dengan password sebelumnya");
                    return ResponseEntity.status(409).body(dataResponse);
                }
            }
        }

        Users data = new Users();
        data.setId(findUsername.getId());
        data.setUsername(request.getUsername());
        data.setPassword(request.getPassword());
        usersRepository.save(data);

        UserRegistrationHistory userRegistrationHistory = new UserRegistrationHistory();
        userRegistrationHistory.setUsername(request.getUsername());
        userRegistrationHistory.setPassword(request.getPassword());
        userRegistrationHistoryRepository.save(userRegistrationHistory);

        dataResponse.setStatus("success");
        dataResponse.setCode("201");
        dataResponse.setData("ok");
        return ResponseEntity.status(201).body(dataResponse);
    }
}
