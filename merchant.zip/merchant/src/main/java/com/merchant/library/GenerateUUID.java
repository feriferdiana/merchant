package com.merchant.library;

import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class GenerateUUID {

    public final static String id(){
        return UUID.randomUUID().toString();
    }
}
