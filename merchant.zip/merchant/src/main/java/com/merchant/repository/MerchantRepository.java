package com.merchant.repository;

import com.merchant.entity.Merchant;
import com.merchant.entity.MerchantType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface MerchantRepository extends JpaRepository<Merchant, String> {

    @Query(" SELECT m FROM Merchant m WHERE m.id = :id ")
    Merchant byId(@Param("id") String id);

    @Query(" SELECT m FROM Merchant m WHERE m.barcode = :bardcode ")
    Merchant byBarcode(@Param("bardcode") String bardcode);

    @Query(" SELECT m FROM Merchant m WHERE m.code = :code ")
    Merchant byCode(@Param("code") String code);

}
