package com.merchant.repository;

import com.merchant.entity.MerchantQueue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
public interface MerchantQueueRepository extends JpaRepository<MerchantQueue, String> {

    @Query(" SELECT m FROM MerchantQueue m WHERE m.idMerchant = :merchantId ORDER BY m.orderQueue DESC")
    List<MerchantQueue> byMerchantId(@Param("merchantId") String merchantId);

    @Query(" SELECT m FROM MerchantQueue m WHERE m.id = :id ")
    MerchantQueue byId(@Param("id") String id);

    @Modifying
    @Transactional
    @Query(" UPDATE MerchantQueue m SET m.status = 'COMPLETED' WHERE m.id = :id ")
    void update(@Param("id") String id);
}
