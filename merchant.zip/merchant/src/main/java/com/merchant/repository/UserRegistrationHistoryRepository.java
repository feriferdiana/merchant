package com.merchant.repository;

import com.merchant.entity.UserRegistrationHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRegistrationHistoryRepository extends JpaRepository<UserRegistrationHistory, Long> {

    @Query("SELECT h FROM UserRegistrationHistory h WHERE h.username = :username")
    List<UserRegistrationHistory> getByUsername(@Param("username") String username);

    @Query(" SELECT h FROM UserRegistrationHistory h " +
            "WHERE h.username = :username AND h.password = :password ")
    UserRegistrationHistory findData(@Param("username") String username,
                                     @Param("password") String password);
}
