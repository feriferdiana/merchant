package com.merchant.repository;

import com.merchant.entity.MerchantMenu;
import com.merchant.entity.MerchantType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MerchantMenuRepository extends JpaRepository<MerchantMenu, String> {

    @Query(" SELECT m FROM MerchantMenu m WHERE m.id = :id ")
    MerchantMenu byId(@Param("id") String id);
}
