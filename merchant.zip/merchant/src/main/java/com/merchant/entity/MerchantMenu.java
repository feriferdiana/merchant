package com.merchant.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "merchant_menu")
public class MerchantMenu {

    @Id
    private String id;

    @Column(name = "id_merchant")
    private String idMerchant;

    @Column(name = "menu")
    private String menu;

    @Column(name = "created_date")
    private LocalDateTime createdDate = LocalDateTime.now();
}
