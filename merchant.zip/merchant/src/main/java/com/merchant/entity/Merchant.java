package com.merchant.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "merchant")
public class Merchant {

    @Id
    private String id;

    @Column(name = "id_merchant_type")
    private String idMerchantType;

    @Column(name = "code")
    private String code;

    @Column(name = "name")
    private String name;

    @Column(name = "address")
    private String address;

    @Column(name = "owner")
    private String owner;

    @Column(name = "barcode")
    private String barcode;

    @Column(name = "created_date")
    private LocalDateTime createdDate = LocalDateTime.now();
}
