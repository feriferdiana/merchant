package com.merchant.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "owner")
public class Owner {

    @Id
    private String id;

    @Column(name = "id_user")
    private String idUser;

    @Column(name = "name")
    private String name;

    @Column(name = "created_date")
    private LocalDateTime createdDate = LocalDateTime.now();
}
