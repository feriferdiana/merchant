package com.merchant.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "merchant_queue_menu")
public class MerchantQueueMenu {

    @Id
    private String id;

    @Column(name = "id_merchant_queue")
    private String idMerchantQueue;

    @Column(name = "id_merchant_menu")
    private String idMerchantMenu;

    @Column(name = "created_date")
    private LocalDateTime createdDate = LocalDateTime.now();
}
