package com.merchant.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "merchant_type")
public class MerchantType {

    @Id
    private String id;

    @Column(name = "type")
    private String type;

    @Column(name = "created_date")
    private LocalDateTime createdDate;
}
