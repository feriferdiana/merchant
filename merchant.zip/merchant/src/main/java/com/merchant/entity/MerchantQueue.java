package com.merchant.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigInteger;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "merchant_queue")
public class MerchantQueue {

    @Id
    private String id;

    @Column(name = "id_merchant")
    private String idMerchant;

    @Column(name = "code_booking")
    private String codeBooking;

    @Column(name = "customer_name")
    private String customerName;

    @Column(name = "order_datetime")
    private LocalDateTime orderDatetime;

    @Column(name = "order_queue")
    private BigInteger orderQueue;

    @Column(name = "status")
    private String status;

    @Column(name = "created_date")
    private LocalDateTime createdDate = LocalDateTime.now();
}
