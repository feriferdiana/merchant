package com.merchant.controller;

import com.merchant.entity.Users;
import com.merchant.model.DataResponse;
import com.merchant.model.users.LoginRequest;
import com.merchant.model.users.RegisterRequest;
import com.merchant.service.UsersService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/api/users")
public class UsersController {

    private UsersService usersService;

    @GetMapping()
    public ResponseEntity<List<Users>> users() {
        return ResponseEntity.ok(usersService.getAllUsers());
    }

    @PostMapping("/login")
    public ResponseEntity<DataResponse> login(@RequestBody LoginRequest request) {
        return usersService.login(request);
    }

    @PostMapping("/login/registrasi")
    public ResponseEntity<DataResponse> regis(@RequestBody RegisterRequest request){
        return usersService.regis(request);
    }

    @PutMapping("/update")
    public ResponseEntity<DataResponse> update(@RequestBody LoginRequest request){
        return usersService.update(request);
    }
}
