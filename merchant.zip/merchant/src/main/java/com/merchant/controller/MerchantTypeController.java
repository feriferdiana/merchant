package com.merchant.controller;

import com.merchant.model.DataResponse;
import com.merchant.model.merchanttype.MerchantTypeRequest;
import com.merchant.service.MerchantTypeService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("api/merchant-type")
@AllArgsConstructor
public class MerchantTypeController {

    private MerchantTypeService merchantTypeService;

    @GetMapping
    public ResponseEntity<DataResponse> all(){
        return ResponseEntity
                .ok(
                        merchantTypeService.all()
                );
    }

    @GetMapping("/{id}")
    public ResponseEntity<DataResponse> id(@PathVariable("id") String id){
        return ResponseEntity
                .ok(
                        merchantTypeService.byId(id)
                );
    }

    @PostMapping
    public ResponseEntity<DataResponse> insert(@RequestBody MerchantTypeRequest request){
        return ResponseEntity
                .ok(
                        merchantTypeService.insert(request)
                );
    }

    @PutMapping
    public ResponseEntity<DataResponse> update(@RequestBody MerchantTypeRequest request){
        return ResponseEntity
                .ok(
                        merchantTypeService.update(request)
                );
    }

    @PutMapping("/{id}")
    public ResponseEntity<DataResponse> deleted(@PathVariable("id") String id){
        return ResponseEntity
                .ok(
                        merchantTypeService.delete(id)
                );
    }
}
