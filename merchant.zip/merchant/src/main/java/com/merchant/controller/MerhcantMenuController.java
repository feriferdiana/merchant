package com.merchant.controller;

import com.merchant.model.DataResponse;
import com.merchant.model.merchantmenu.MerchantMenuRequest;
import com.merchant.service.MerchantMenuService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/api/merchant-menu")
public class MerhcantMenuController {

    private MerchantMenuService merchantMenuService;

    @PostMapping
    public ResponseEntity<DataResponse> addMenu(@RequestBody MerchantMenuRequest request){
        return ResponseEntity
                .ok(
                        merchantMenuService.addMenu(request)
                );
    }

}
