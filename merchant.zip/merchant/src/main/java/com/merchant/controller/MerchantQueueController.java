package com.merchant.controller;

import com.merchant.model.DataResponse;
import com.merchant.model.merchantqueue.OrderRequest;
import com.merchant.service.MerchantQueueService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/api/merchant-queue")
public class MerchantQueueController {

    private MerchantQueueService merchantQueueService;

    @PostMapping("/order")
    public ResponseEntity<DataResponse> register(@RequestBody OrderRequest request){
        return ResponseEntity
                .ok(
                        merchantQueueService.order(request)
                );
    }

    @GetMapping("/completed/{id}")
    public ResponseEntity<DataResponse> completed(@PathVariable("id") String id){
        return ResponseEntity
                .ok(
                        merchantQueueService.completed(id)
                );
    }

    @GetMapping("/check/{id}")
    public ResponseEntity<DataResponse> check(@PathVariable("id") String id){
        return ResponseEntity
                .ok(
                        merchantQueueService.check(id)
                );
    }

}
