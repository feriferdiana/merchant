package com.merchant.controller;

import com.merchant.model.DataResponse;
import com.merchant.model.merchant.MerchantRequest;
import com.merchant.service.MerchantService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/api/merchant")
public class MerhcantController {

    private MerchantService merchantService;

    @PostMapping("/register")
    public ResponseEntity<DataResponse> register(@RequestBody MerchantRequest request){
        return ResponseEntity
                .ok(
                        merchantService.register(request)
                );
    }

}
