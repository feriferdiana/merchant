package com.merchant.enumeration;

public enum StatusBooking {
    ON_PROGRESS, CANCEL, COMPLETED;
}
